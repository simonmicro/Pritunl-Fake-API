from pritunl.cachelocal.cache_trie import *

from pritunl import tunldb

cache_db = tunldb.TunlDB()
