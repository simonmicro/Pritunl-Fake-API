from pritunl import cache

def setup_cache():
    cache.init()
