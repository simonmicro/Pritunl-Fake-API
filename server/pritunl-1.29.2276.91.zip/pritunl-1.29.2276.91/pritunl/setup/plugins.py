from pritunl import plugins

def setup_plugins():
    plugins.init()
