library boilerplate_comp;

import 'package:angular/angular.dart' show Component, NgTwoWay, NgAttr;

@Component(
  selector: 'x-boilerplate',
  templateUrl: 'packages/pritunl/components/boilerplate/boilerplate.html',
  cssUrl: 'packages/pritunl/components/boilerplate/boilerplate.css'
)
class BoilerplateComp {
  BoilerplateComp() {
  }
}
